# WebScraping
 Web scraping, fetch data from mercadolibre and save into excel
 
  1. Clone this project 
  2. Create a virtualenv
  3. Install dependencies with pip install -r requirements.txt
  4. Run script scraper.py
  5. Check the xlsx output